#/usr/lib/jdk1.6.0_45/bin/javac  *.java
/cad2/ece419s/java/jdk1.6.0/bin/javac  *.java 
