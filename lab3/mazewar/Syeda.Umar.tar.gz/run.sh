#!/bin/bash
JAVA_HOME=/cad2/ece419s/java/jdk1.6.0/
#JAVA_HOME=/usr/lib/jdk1.6.0_45/

${JAVA_HOME}/bin/java Mazewar 
